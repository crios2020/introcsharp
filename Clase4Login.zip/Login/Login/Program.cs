﻿using System;

namespace Login
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            string[] usuarios = {"Juan", "Ana", "Jose", "Maria" };
            string[] claves   = {"123",  "321", "111",  "abc"   };

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("***********************************************");
            Console.WriteLine("*         Ingreso al sistema                  *");
            Console.WriteLine("***********************************************");

            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine();
            Console.Write("Ingrese su nombre de Usuario: ");
            string user = Console.ReadLine();
            Console.WriteLine();
            Console.Write("Ingrese su clave: ");
            string pass = Console.ReadLine();

            bool existe = false;
            int donde = 0;

            for(int a=0; a<usuarios.Length; a++)
            {
                if (user == usuarios[a])
                {
                    existe = true;
                    donde = a;
                    break;
                }
            }

            //Console.WriteLine(existe + " " + donde);
            if (existe)
            {
                if (pass == claves[donde])
                {
                    Console.WriteLine("Bienvenido "+user+"!");
                }
                else
                {
                    Console.WriteLine("Clave Incorrecta!");
                }
            }
            else
            {
                Console.WriteLine("Usuario Inexistente!");
            }


        }
    }
}
