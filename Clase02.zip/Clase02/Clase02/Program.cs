﻿using System;

namespace Clase02
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Clase 02");

            /*
                Operadores Logicos

                Operador            Nombre
                    ==              equals (comparación)
                    !=              not equals (distinto)
                    !               not (no)
                    < <= >= >       relacionales
                    &&              and (y)                 shift &
                    ||              or (o)                  altgr 1                   

             */

            /*
                Tabla de verdad

                    X       Y          OR          AND
                    F       F           F           F
                    F       V           V           F
                    V       F           V           F
                    V       V           V           V
            */

            bool log1 = true;
            bool log2 = false;
            int nro1 = 5;
            int nro2 = 7;

            Console.WriteLine(log1 && log2);        //false
            Console.WriteLine(log1 || log2);        //true

            Console.WriteLine(nro1 + 2 == nro2 && !log2);       //true

            Console.WriteLine(log2 && nro1 + 2 == nro2);        //false

            Console.WriteLine(!log2 || nro1 + 2 == nro2);       //true

            //Operador binarios
            //  |  Or binario
            //  &  And binario
            Console.WriteLine("Operadores Binarios | &");
            Console.WriteLine(log1 & log2);        //false
            Console.WriteLine(log1 | log2);        //true

            Console.WriteLine(nro1 + 2 == nro2 & !log2);       //true

            Console.WriteLine(log2 & nro1 + 2 == nro2);        //false

            Console.WriteLine(!log2 | nro1 + 2 == nro2);       //true


            Console.WriteLine(!!log1 && log2 != log1 && nro1 + 2 <= nro2 + 1 && (nro1 == nro2 || nro2 <= nro1 || !!!log2));


            //Estructura condicional IF
            if (true)
            {
                Console.WriteLine("Verdad 1");
            }

            if (nro1 == 5)
            {
                //código indentado
                Console.WriteLine("Verdad 2");
                Console.WriteLine("Hoy es Sábado");
                Console.WriteLine("esta soleado");
            }

            //uso de llaves expandido - Modo recomendado por Microsoft
            if (nro1 == 8)
            {
                Console.WriteLine("Verdad 3");
            }

            //uso de llaves comprimido - No recomendado
            if (nro1 == 5) {
                Console.WriteLine("Verdad 4");
            }

            //uso de llaves omitido
            if (nro1 == 5) Console.WriteLine("Verdad 5");


            //Estructura if else
            if(nro1==5)
            {
                Console.WriteLine("Verdad 6");
            }
            else
            {
                Console.WriteLine("Falso 6");
            }

            //Modo de llaves expandido - recomendado por Microsoft
            if (nro1 == 5)
            {
                Console.WriteLine("Verdad 7");
            }
            else
            {
                Console.WriteLine("Falso 7");
            }

            //Modo de llaves comprimido
            if (nro1 == 5){
                Console.WriteLine("Verdad 8");
            } else {
                Console.WriteLine("Falso 8");
            }

            //Modo de llaves omitido
            if (nro1 == 5) Console.WriteLine("Verdad 9");
            else Console.WriteLine("Falso 10");


            //Dia de la semana
            Console.WriteLine(DateTime.Now.DayOfWeek);
            int diaSemana = (int)DateTime.Now.DayOfWeek; // 0 domingo ... 6 sábado
            Console.WriteLine(diaSemana);

            if (diaSemana == 0) Console.WriteLine("Domingo");
            if (diaSemana == 1) Console.WriteLine("Lunes");
            if (diaSemana == 2) Console.WriteLine("Martes");
            if (diaSemana == 3) Console.WriteLine("Miércoles");
            if (diaSemana == 4) Console.WriteLine("Jueves");
            if (diaSemana == 5) Console.WriteLine("Viernes");
            if (diaSemana == 6) Console.WriteLine("Sábado");

            if (diaSemana == 0 || diaSemana == 6) Console.WriteLine("Es Fin de Semana");
            else Console.WriteLine("Es día laboral");

            //Mes del año
            int mesAnio = (int)DateTime.Now.Month; //1 enero .... 12 diciembre
            Console.WriteLine(mesAnio);

            if (mesAnio == 1) Console.WriteLine("Enero");
            if (mesAnio == 2) Console.WriteLine("Febrero");
            if (mesAnio == 3) Console.WriteLine("Marzo");
            if (mesAnio == 4) Console.WriteLine("Abril");
            if (mesAnio == 5) Console.WriteLine("Mayo");
            if (mesAnio == 6) Console.WriteLine("Junio");
            if (mesAnio == 7) Console.WriteLine("Julio");
            if (mesAnio == 8) Console.WriteLine("Agosto");
            if (mesAnio == 9) Console.WriteLine("Septiembre");
            if (mesAnio == 10) Console.WriteLine("Octubre");
            if (mesAnio == 11) Console.WriteLine("Noviembre");
            if (mesAnio == 12) Console.WriteLine("Diciembre");

            //Estructura Switch
            switch (diaSemana)
            {
                case 1: Console.WriteLine("Lunes"); break;
                case 2: Console.WriteLine("Martes"); break;
                case 3: Console.WriteLine("Miércoles"); break;
                case 4: Console.WriteLine("Jueves"); break;
                case 5: Console.WriteLine("Viernes"); break;
                case 6: 
                    Console.WriteLine("Sábado");
                    Console.WriteLine("Es fin de semana");
                    break;
                case 0: Console.WriteLine("Domingo"); break;
            }


            // Pendiente Terminar Switch


        }
    }
}
