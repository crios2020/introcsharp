﻿using System;

namespace Clase4
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Clase 4 Vectores - Arrays - Arreglos");

            //Declaración de vector
            int[] numeros = new int[4];
            string[] nombres = new string[4];

            //carga de valores
            numeros[0] = 1;
            nombres[0] = "Juan";
            numeros[1] = 2;
            nombres[1] = "Maria";
            numeros[2] = 3;
            nombres[2] = "Jose";
            numeros[3] = 4;
            nombres[3] = "Ana";

            //error
            //numeros[4] = 5;
            //nombres[4] = "Mirta";
            //numeros[-1] = 1;
            //nombres[-1] = "Juan";

            /*
             *      numeros         nombres         indice
             *          1           Juan            0
             *          2           Maria           1
             *          3           Jose            2
             *          4           Ana             3            
             */

            //imprimir una posición del vector
            Console.WriteLine(numeros[2] + " " + nombres[2]);

            //Redimensionar un vector
            Array.Resize(ref numeros, 6);
            Array.Resize(ref nombres, 6);

            numeros[4] = 5;
            nombres[4] = "Mirta";
            numeros[5] = 6;
            nombres[5] = "Eliana";

            //cambio de valor en posición indice 2
            nombres[2] = "Cristian";

            //Recorrido de vectores
            Console.WriteLine("***********************************************");
            for (int a = 0; a < 6; a++) Console.WriteLine(numeros[a] + " " + nombres[a]);

            //Método length
            Console.WriteLine("Longitud de vector: " + numeros.Length);

            //Recorrido usando Length
            Console.WriteLine("***********************************************");
            for (int a = 0; a < numeros.Length; a++) Console.WriteLine(numeros[a] + " " + nombres[a]);

            //Recorrido usando while
            Console.WriteLine("***********************************************");
            int x = 0;
            while (x < numeros.Length)
            {
                Console.WriteLine(numeros[x] + " " + nombres[x]);
                x++;
            }

            //Recorrido inverso
            Console.WriteLine("***********************************************");
            for (int a = numeros.Length - 1; a >= 0; a--) Console.WriteLine(numeros[a] + " " + nombres[a]);

            //Declaración abreviada
            int[] vector = { 38, 39, 26, 23, 29, 14, 10, 16, 26, 24, 32, 45 };
            string[] semana = { "Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado" };
            string[] meses = { "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" };

            Console.WriteLine("Longitud vector: " + vector.Length);
            Console.WriteLine("Longitud semana: " + semana.Length);
            Console.WriteLine("Longitud meses: " + meses.Length);

            //Dia de la semana
            Console.WriteLine(DateTime.Now.DayOfWeek);
            int diaSemana = (int)DateTime.Now.DayOfWeek; // 0 domingo ... 6 sábado
            Console.WriteLine(diaSemana);

            //Nro dia del mes
            int diaMes = DateTime.Now.Day;

            //Mes del año
            int mesAnio = (int)DateTime.Now.Month; //1 enero .... 12 diciembre
            Console.WriteLine(mesAnio);

            //Año
            int anio = DateTime.Now.Year;

            Console.WriteLine("Hoy es " + semana[diaSemana] + " "
                                + diaMes + " de " + meses[mesAnio - 1]
                                + " de " + anio);

            // Recorrido de vector
            for (int a = 0; a < vector.Length; a++) Console.Write(vector[a] + " ");
            Console.WriteLine();
            //int[] vector = {38, 39, 26, 23, 29, 14, 10, 16, 26, 24, 32, 45 };

            //Totalizar vector
            //Promediar un vector
            int total = 0;
            for (int a = 0; a < vector.Length; a++)
            {
                total += vector[a];
            }
            Console.WriteLine("Total: " + total);
            Console.WriteLine("Promedio: " + ((float)total / vector.Length));

            //Calcular de Valor mínimo y valor máximo.
            //int[] vector = {38, 39, 26, 23, 29, 14, 10, 16, 26, 24, 32, 45 };
            int max = vector[0], min = vector[0];
            for (int a = 1; a < vector.Length; a++)
            {
                if (max < vector[a]) max = vector[a];
                if (min > vector[a]) min = vector[a];
            }
            Console.WriteLine("Valor máximo: " + max);
            Console.WriteLine("Valor mínimo: " + min);

            //Operador resto %
            Console.WriteLine(17 % 3);          // 2
            Console.WriteLine(16 % 3);          // 1
            Console.WriteLine(15 % 3);          // 0

            Console.WriteLine(15 % 2);          // 1
            Console.WriteLine(14 % 2);          // 0
            Console.WriteLine(-14 % 2);         // 0
            Console.WriteLine(-15 % 2);         //-1

            //Contar cantidad de números pares, cantidad números impares,
            //cantidad número 26
            int contPares = 0, contImpares = 0, cont26 = 0;
            for (int a = 0; a < vector.Length; a++)
            {
                if (vector[a] % 2 == 0) contPares++;
                else contImpares++;
                if (vector[a] == 26) cont26++;
            }
            Console.WriteLine("Cantidad números pares: " + contPares);
            Console.WriteLine("Cantidad números impares: " + contImpares);
            Console.WriteLine("Cantidad número 26: " + cont26);

            //copia de vectores

            int[] pares = { 2, 4, 6, 8, 10 };
            int[] impares = new int[pares.Length];
            int[] pares2 = new int[pares.Length];

            /*
             *      pares           impares         pares
             *          2           _1_             ___
             *          4           _3_             ___
             *          6           _5_             ___
             *          8           _7_             ___
             *         10           _9_             ___
             */

            for (int a = 0; a < pares.Length; a++)
            {
                impares[a] = pares[a] - 1;
            } 

            for(int a=0; a<pares.Length; a++)
            {
                Console.WriteLine(impares[a] + " " + pares[a]);
            }

            Array.Copy(pares, pares2, pares.Length);
            for (int a = 0; a < pares.Length; a++)
            {
                Console.WriteLine(pares[a] + " " + pares2[a]);
            }

            //recorro vector
            for (int a = 0; a < vector.Length; a++) Console.Write(vector[a] + " ");
            Console.WriteLine();

            //ordena el vector
            Array.Sort(vector);

            //recorro vector
            for (int a = 0; a < vector.Length; a++) Console.Write(vector[a] + " ");
            Console.WriteLine();

            //revertir el vector
            Array.Reverse(vector);

            //recorro vector
            for (int a = 0; a < vector.Length; a++) Console.Write(vector[a] + " ");
            Console.WriteLine();

            Array.Sort(meses);
            for (int a = 0; a < meses.Length; a++) Console.WriteLine(meses[a]);


        }
    }
}
