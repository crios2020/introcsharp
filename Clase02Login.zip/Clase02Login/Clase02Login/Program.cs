﻿using System;

namespace Clase02Login
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //User: root        Pass: 123

            //Console.BackgroundColor = ConsoleColor.Gray;    //Color de fondo
            Console.ForegroundColor = ConsoleColor.Blue;    //Color de fuente
            Console.WriteLine("***********************************************");
            Console.WriteLine("*         Ingreso al sistema                  *");
            Console.WriteLine("***********************************************");
            //Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine();
            Console.Write("Ingrese su nombre de Usuario: ");
            string user = Console.ReadLine();
            Console.WriteLine();
            Console.Write("Ingrese su clave: ");
            string pass = Console.ReadLine();

            //Console.WriteLine(user + " " + pass);

            if (user == "root")
            {
                if (pass == "123")
                {
                    Console.WriteLine("Bienvenido Usuario!");
                }
                else
                {
                    Console.WriteLine("Clave Incorrecta!");
                }
            }
            else
            {
                Console.WriteLine("Usuario Incorrecto!");
            }

            //if (user == "root" && pass == "123")    Console.WriteLine("Bienvenido Usuario!");
            //if (user == "root" && pass != "123")    Console.WriteLine("Clave Incorrecta!");
            //if (user != "root" )                    Console.WriteLine("Usuario Incorrecto!");


            Console.ResetColor();
        }
    }
}
