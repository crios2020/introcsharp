﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase05_Gestion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            //Evento Limpiar
            txtUsuario.Text = "";
            txtClave.Text = "";
            lblInfo.Text = "";
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //Evento Login
            string[] usuarios = { "Juan", "Ana", "Jose", "Maria" };
            string[] claves = { "123", "321", "111", "abc" };

            string user = txtUsuario.Text;
            string pass = txtClave.Text;

            bool existe = false;
            int donde = 0;

            for (int a = 0; a < usuarios.Length; a++)
            {
                if (user == usuarios[a])
                {
                    existe = true;
                    donde = a;
                    break;
                }
            }

            if (existe)
            {
                if (pass == claves[donde])
                {
                    lblInfo.ForeColor= System.Drawing.Color.FromArgb(0, 0, 255);
                    lblInfo.Text="Bienvenido " + user + "!";
                }
                else
                {
                    lblInfo.ForeColor = System.Drawing.Color.FromArgb(255, 0, 0);
                    lblInfo.Text="Clave Incorrecta!";
                }
            }
            else
            {
                lblInfo.ForeColor = System.Drawing.Color.FromArgb(255, 0, 0);
                lblInfo.Text = "Usuario Inexistente!";
            }
        }
    }
}
