﻿using System;

namespace Clase01
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            /*
                Curso:  C# .net Inicial      15 hs
                Días:   Sábados 10:00 a 13:00 hs
                Profe:  Carlos Rios      carlos.rios@educacionit.com

                Software:   visual studio community     2015 o sup.   (IDE)
                        alternativos (IDE):   visual studio code - sharpDevelop - monoDevelop
                
                Materiales: alumni.educacionit.com
                            user:   email 
                            pass:   dni
                            alumnos@educacionit.com
                 
                 github:    https://github.com/crios2020/introcsharp
                           
                       
                 IDE: Integrated Development Enviroment
             */

            /* Bloque de comentarios */
            //linea de comentarios

            Console.WriteLine("Hola Mundo!");       //imprime en consola
            //lenguaje es case sensitive
            // ; es el terminador de sentencias

            // F5 ejecutamos el programa

            Console.WriteLine("Hoy es Sábado");
            Console.Write("1");
            Console.Write("2");
            Console.Write("3");
            Console.WriteLine("4");

            /*
                Hola Mundo!
                Hoy es Sábado
                1234
                Presione una tecla para continuar.
                               
             */

            // Variables
            // C# - Java - Visual Basic - C++ - TypeScript, son lenguajes tipado fuertes
            // Python - JavaScript - PHP, son lenguajes de tipado debil

            //tipo de datos int
            int a;          //declara una variable entera
            a = 2;          //asigna valor a la variable

            int b = 4;      //declara y asigna valor a una variable

            int c = a + b;

            int d = 23, e = 26, f = 39, g = 38; //declaración y asignación de multiples variables

            Console.WriteLine(a);
            Console.WriteLine("Variable a: " + a);
            Console.WriteLine("a+b=" + a + b);      //a+b=24
            Console.WriteLine("a+b=" + c);
            Console.WriteLine("a+b=" + (a + b));

            //Tipo de datos string
            string p = "Recreo";
            string t = "cafe";
            Console.WriteLine(p + t);
            Console.WriteLine(p + " " + t);
            Console.WriteLine(p + " y " + t);

            //Tipo de datos char
            char ch = 'a';
            Console.WriteLine(ch);

            //Tipo de datos float   32 bits
            float fl = 9.45f;
            Console.WriteLine(fl);

            //Tipo de datos double  64 bits
            double dl = 9.45;
            Console.WriteLine(dl);

            fl = 10;
            dl = 10;
            Console.WriteLine(fl / 3);
            Console.WriteLine(dl / 3);

            int x = 10;
            float y = 3.3f;
            Console.WriteLine(x/y);

            //Tipo de datos boolean
            bool bo = true;
            Console.WriteLine(bo);
            bo = false;
            Console.WriteLine(bo);

            //Operador de asignación =
            int nro1 = 5;
            int nro2 = 7;

            Console.WriteLine(nro1 + " " + nro2);
            nro1 = nro2+nro1;   //12
            nro1 = nro2;        //7
            // <----
            Console.WriteLine(nro1 + " " + nro2);

            //Operadores incrementales

            //Sumar 1 a la variable nro1            ++
            nro1++ ;             //nro1=nro1+1;
            Console.WriteLine(nro1);

            //Restar 1 a la variable nro1       --
            nro1--;             //nro1=nro1-1;
            Console.WriteLine(nro1);

            //Sumar x a la variable nro1        +=
            nro1+=5;            //nro1=nro1+5
            Console.WriteLine(nro1);

            //Restar x a la variable nro1       -=
            nro1 -= 5;          //nro1=nro1-5;
            Console.WriteLine(nro1);

            //Multiplicar la variable nro1      *=
            nro1 *= 5;          //nro1=nro1*5;
            Console.WriteLine(nro1);

            //Dividir la variable nro1          /=
            nro1 /= 5;          //nro1=nro1/5;
            Console.WriteLine(nro1);

            //Precedencia y procedencia de operaros unarios ++ --
            Console.WriteLine(nro1++);
            Console.WriteLine(nro1);
            Console.WriteLine(++nro1);

            //Declaración de constantes
            //Una constante, pertenece a un tipo de datos, solo puede tener una asignación de valor
            //          en el momento de la declaración
            const double PI = 3.14;
            //PI++; //error


            //Console.WriteLine("Ingrese su nombre:");
            //string nombre = Console.ReadLine();         //lee desde consola
            //Console.WriteLine("Hola " + nombre);

            //Console.WriteLine("Ingrese un entero:");
            //int n1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("Ingrese otro entero: ");
            //int n2 = int.Parse(Console.ReadLine());
            //int suma = n1 + n2;
            //Console.WriteLine("Total: " + suma);

            /*
                Operadores Logicos

                Operador            Nombre
                    ==              equals (comparación)
                    !=              not equals (distinto)
                    !               not (no)
                    < <= >= >       relacionales
                    &&              and (y)                 shift &
                    ||              or (o)                  altgr 1                   
           
             */

            nro1 = 5;
            nro2 = 7;
            bool log1 = true;
            bool log2 = false;

            Console.WriteLine(nro1 == nro2);            //false
            Console.WriteLine(nro1 + 2 == nro2);        //true

            Console.WriteLine(nro1 != nro2);            //true
            Console.WriteLine(nro1 + 2 != nro2);        //false

            Console.WriteLine(log1);                    //true
            Console.WriteLine(!log1);                   //false
            Console.WriteLine(!!log1);                  //true
            Console.WriteLine(!!!log1);                 //false
            Console.WriteLine(!!!!log1);                //true

            Console.WriteLine(nro1 < nro2);             //true
            Console.WriteLine(nro1 <= nro2);            //true
            Console.WriteLine(nro1 > nro2);             //false
            Console.WriteLine(nro1 >= nro2);            //false

            /*
                Tabla de verdad

                    X       Y          OR          AND
                    F       F           F           F
                    F       V           V           F
                    V       F           V           F
                    V       V           V           V
            */

            Console.WriteLine(log1 || log2);        //true
            Console.WriteLine(log1 && log2);        //false

            //Pendientes Continuar con más expresiones logicas

            //Console.WriteLine("Presione una tecla para continuar.");
            //Console.ReadKey();
        }
    }
}
