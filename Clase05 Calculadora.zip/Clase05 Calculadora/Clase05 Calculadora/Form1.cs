﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase05_Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            //Evento Borrar
            txtNum1.Text = "0";
            txtNum2.Text = "0";
            lblRes.Text = "0";

        }

        private void btnSuma_Click(object sender, EventArgs e)
        {
            //Evento Suma
            int nro1 = int.Parse(txtNum1.Text);
            int nro2 = int.Parse(txtNum2.Text);
            int res = nro1 + nro2;
            lblRes.Text = res+"";
        }

        private void btnResta_Click(object sender, EventArgs e)
        {
            //Evento Resta
            int nro1 = int.Parse(txtNum1.Text);
            int nro2 = int.Parse(txtNum2.Text);
            int res = nro1 - nro2;
            lblRes.Text = res + "";
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            //Evento Multi
            int nro1 = int.Parse(txtNum1.Text);
            int nro2 = int.Parse(txtNum2.Text);
            int res = nro1 * nro2;
            lblRes.Text = res + "";
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            //Evento Div
            int nro1 = int.Parse(txtNum1.Text);
            int nro2 = int.Parse(txtNum2.Text);
            int res = nro1 / nro2;
            lblRes.Text = res + "";
        }
    }
}
