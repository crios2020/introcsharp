﻿using System;
using System.Threading;

namespace Clase3
{
    class MainClass
    {

        //Declaración de atributos
        static int clase;
        static string texto;
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            // Declaración de variables
            int x;
            string t;
            double saldo;
            //Console.WriteLine(x);       //error variable no inicializada
            //Console.WriteLine(t);       //error variable no inicializada
            //Console.WriteLine(saldo);

            //Los atributos tienen un proceso de inicialización automatico
            Console.WriteLine(clase);
            Console.WriteLine(texto);

            //Dia de la semana
            Console.WriteLine(DateTime.Now.DayOfWeek);
            int diaSemana = (int)DateTime.Now.DayOfWeek; // 0 domingo ... 6 sábado
            Console.WriteLine(diaSemana);

            //Mes del año
            int mesAnio = (int)DateTime.Now.Month; //1 enero .... 12 diciembre
            Console.WriteLine(mesAnio);

            //Estructura Switch
            switch (diaSemana)
            {
                case 1: Console.WriteLine("Lunes"); break;
                case 2: Console.WriteLine("Martes"); break;
                case 3: Console.WriteLine("Miércoles"); break;
                case 4: Console.WriteLine("Jueves"); break;
                case 5: Console.WriteLine("Viernes"); break;
                case 6:
                    Console.WriteLine("Sábado");
                    Console.WriteLine("Es fin de semana");
                    break;
                case 0: Console.WriteLine("Domingo"); break;
            }
            diaSemana = 26;
            switch (diaSemana)
            {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    Console.WriteLine("Hoy es día laboral!");
                    break;
                case 0:
                case 6:
                    Console.WriteLine("Es fin de semana!");
                    break;
                default:
                    Console.WriteLine("Error!");
                    break;
            }


            //Estructura While
            int a = 20;
            Console.WriteLine("-- Inicio de Estructura While --");
            while (a <= 10)
            {
                Console.WriteLine(a);
                a++;
            }
            Console.WriteLine("-- Fin de Estructura While --");
            Console.WriteLine(a);

            //Estructura Do While
            a = 20;
            Console.WriteLine("-- Inicio de Estructura Do While --");
            do
            {
                Console.WriteLine(a);
                a++;
            } while (a <= 10);
            Console.WriteLine("-- Fin de Estructura Do While --");
            Console.WriteLine(a);


            double v = 0;
            while (v <= 10)
            {
                Console.WriteLine(v);
                v += 0.4;
            }

            /*
            Console.WriteLine(DateTime.Now.DayOfWeek);
            diaSemana = (int)DateTime.Now.DayOfWeek; // 0 domingo ... 6 sábado
            Console.WriteLine(diaSemana);
            string dia = "";
            switch (diaSemana)
            {
                case 1: dia="Lunes"; break;
                case 2: dia="Martes"; break;
                case 3: dia="miércoles"; break;
                case 4: dia="Jueves"; break;
                case 5: dia="Viernes"; break;
                case 6: dia="Sábado"; break;
                case 0: dia="Domingo"; break;
            }

            while (dia != "Domingo")
            {
                diaSemana = (int)DateTime.Now.DayOfWeek; // 0 domingo ... 6 sábado
                //Console.WriteLine(diaSemana);
                switch (diaSemana)
                {
                    case 1: dia = "Lunes"; break;
                    case 2: dia = "Martes"; break;
                    case 3: dia = "miércoles"; break;
                    case 4: dia = "Jueves"; break;
                    case 5: dia = "Viernes"; break;
                    case 6: dia = "Sábado"; break;
                    case 0: dia = "Domingo"; break;
                }
                Console.WriteLine(dia);
            }


            do
            {
                diaSemana = (int)DateTime.Now.DayOfWeek; // 0 domingo ... 6 sábado
                //Console.WriteLine(diaSemana);
                switch (diaSemana)
                {
                    case 1: dia = "Lunes"; break;
                    case 2: dia = "Martes"; break;
                    case 3: dia = "miércoles"; break;
                    case 4: dia = "Jueves"; break;
                    case 5: dia = "Viernes"; break;
                    case 6: dia = "Sábado"; break;
                    case 0: dia = "Domingo"; break;
                }
                Console.WriteLine(dia);
            } while (dia != "Domingo") ;
            */

            //Uso de llaves expandido recomendado por Microsoft
            a = 1;
            while (a <= 10)
            {
                Console.WriteLine(a);
                a++;
            }

            //Uso de llaves compacto (java)
            a = 1;
            while (a <= 10)
            {
                Console.WriteLine(a);
                a++;
            }

            //Uso de llaves abreviado
            a = 1;
            while (a <= 10) Console.WriteLine(a++);

            // Loop Infinito
            //a = 1;
            //while (true)
            //{
            //    Console.WriteLine(a);
            //    a++;
            //}

            // Loop Infinito
            //a = 1;
            //while (a<=10 || true)
            //{
            //    Console.WriteLine(a);
            //    a++;
            //}

            // Loop Infinito
            //a = 1;
            //while (a<=10 || a>=1)
            //{
            //    Console.WriteLine(a);
            //    a++;
            //}

            // Loop Infinito
            //a = 1;
            //while (a<=10)
            //{
            //    Console.WriteLine(a--);
            //    a++;
            //}

            // Loop Infinito
            //a = 1;
            //while (a<=10) ;
            //{
            //    Console.WriteLine(a);
            //    a++;
            //}

            a = 1;
            Console.WriteLine("-- Inicio de Estructura While --");
            while (a <= 10)
            {
                Console.WriteLine(a);
                a++;
            }
            Console.WriteLine("-- Fin de Estructura While --");
            Console.WriteLine(a);

            //Estructura for
            Console.WriteLine("-- Inicio Estructura For --");

            for(int s=1; s<=10; s++)
            {
                Console.WriteLine(s);
            }
            Console.WriteLine("-- Fin Estructura For --");
            //Console.WriteLine(s); //error variable fuera de scope

            //Uso de llaves expandido recomendado por microsoft
            for (int s = 1; s <= 10; s++)
            {
                Console.WriteLine(s);
            }

            //Uso de llaves comprimido java
            for (int s = 1; s <= 10; s++) {
                Console.WriteLine(s);
            }

            //Uso de llaves abreviado
            for (int s = 1; s <= 10; s++) Console.WriteLine(s);

            //Recorrido con variable global
            for (a = 1; a <= 10; a++)
            {
                Console.WriteLine(a);
            }
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine(a);
            Console.WriteLine("-----------------------------------------------");
            for (a++; a <= 20; a++)
            {
                Console.WriteLine(a);
            }
            Console.WriteLine("-----------------------------------------------");
            for (; a <= 30; a++)
            {
                Console.WriteLine(a);
            }

            //Sentencia break y continue
            Console.WriteLine("-----------------------------------------------");
            for (int s = 1; s <= 20; s++)
            {
                if (s == 5 || s == 10) continue;
                Console.WriteLine(s);
                if (s == 12) break;
            }

            Console.WriteLine("-----------------------------------------------");
            for(int s=1; s<=12; s++)
            {
                if (s != 5 && s != 10) Console.WriteLine(s);
            }

            //Omisión de parametros
            a = 1;
            for(; ; )
            {
                if (a > 10) break;
                Console.WriteLine(a);
                a++;
            }

            //Recorrido con multiples variables de control

            for(int r=1, s=1 ; r<=5 && s<=10; r++, s++)
            {
                Console.WriteLine(r + " " + s);
            }

            for (int r = 1, s = 1; r <= 5 || s <= 10; r++, s++)
            {
                Console.WriteLine(r + " " + s);
            }

            //For anidado
            int cont = 0;
            for(int r = 1; r <= 10; r++)
            { 
                for(int s=1;s<=10; s++)
                { 
                    for(int y = 1; y <= 10; y++)
                    { 
                        cont++;
                        Console.WriteLine(r + " " + s + " " + y + " " +cont);
                    }
                }
            }

            //Horas del día
            
            //for(int hora = DateTime.Now.Hour; hora < 24; hora++)
            //{
            //    for(int minuto = DateTime.Now.Minute; minuto < 60; minuto++)
            //    {
            //        for(int segundo = DateTime.Now.Second; segundo < 60; segundo++)
            //        {
            //            Console.WriteLine(
            //                        hora.ToString("00") + ":" + 
            //                        minuto.ToString("00") + ":" + 
            //                        segundo.ToString("00"));
            //            Thread.Sleep(1000);
            //        }
            //    }
            //}

            double precio = 10000009.50;
            Console.WriteLine(precio);
            Console.WriteLine(precio.ToString("###,###,###.00"));

            //Loop infinito
            //for(int s=1; ; s++)
            //{
            //    Console.WriteLine(s);
            //}

            //Loop infinito
            //for (int s = 1; true; s++)
            //{
            //    Console.WriteLine(s);
            //}

            //Loop infinito
            //for (int s = 1; s<=10 || true ; s++)
            //{
            //    Console.WriteLine(s);
            //}

            //Loop infinito
            //for (int s = 1; s<=10 || s>=1; s++)
            //{
            //    Console.WriteLine(s);
            //}

            //Loop infinito
            //for (int s = 1; s<=10; s++)
            //{
            //    Console.WriteLine(s--);
            //}

            //Loop infinito
            //a = 2;
            //for (int s = a; a<=10 ; s++)
            //{
            //    Console.WriteLine(s);
            //}

            //Loop infinito
            //a = 2;
            //for (int s = a; s <= 10; a++)
            //{
            //    Console.WriteLine(s);
            //}

        }
    }
}
